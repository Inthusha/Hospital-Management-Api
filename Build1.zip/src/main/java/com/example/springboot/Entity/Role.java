package com.example.springboot.Entity;

public enum Role 
{
	
	ADMIN,
	DOCTOR,
	ATTENDER

}
